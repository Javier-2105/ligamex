import React from 'react';
import { Team } from '../types';

interface TeamDetailProps {
  team: Team;
  isVisible: boolean;
  onClose: () => void;
}

const CloseIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    </svg>
);

const InfoCard: React.FC<{ title: string; children: React.ReactNode; color: string;}> = ({ title, children, color }) => (
  <div className="bg-black/20 backdrop-blur-sm rounded-xl p-6 shadow-lg transform transition-all duration-500 hover:scale-105 hover:shadow-2xl">
    <h3 className="text-2xl font-bold mb-4 border-b-2 pb-2" style={{ borderColor: color, color }}>{title}</h3>
    {children}
  </div>
);

const TeamDetail: React.FC<TeamDetailProps> = ({ team, isVisible, onClose }) => {
  const gradientStyle = {
    background: `linear-gradient(135deg, ${team.colors.primary}, ${team.colors.secondary})`,
    backgroundSize: '200% 200%',
    animation: 'moveGradient 15s ease infinite',
  };

  const textPrimaryStyle = { color: team.colors.text };
  const goalsPerGame = team.gamesPlayed > 0 ? (team.totalGoals / team.gamesPlayed).toFixed(2) : 'N/A';
  
  return (
    <div
      className={`fixed inset-0 z-50 transition-opacity duration-500 ease-in-out ${isVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
    >
      <div className="absolute inset-0 bg-black/60" onClick={onClose}></div>
      
      <div 
        className={`fixed inset-0 overflow-y-auto transform transition-transform duration-700 ease-in-out ${isVisible ? 'translate-y-0' : 'translate-y-full'}`}
        style={gradientStyle}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-50 rounded-full p-2 bg-black/30 hover:bg-black/50 transition-colors"
          aria-label="Cerrar"
          style={textPrimaryStyle}
        >
          <CloseIcon className="h-8 w-8" />
        </button>

        <div className="container mx-auto p-4 sm:p-8 md:p-12 text-white">
          <header className="flex flex-col md:flex-row items-center gap-8 mb-12">
            <div className="bg-white/90 rounded-full p-4 shadow-2xl flex-shrink-0 will-animate animate-subtle-zoom">
              <img src={team.logoUrl} alt={`${team.name} logo`} className="h-32 w-32 md:h-48 md:w-48 object-contain" />
            </div>
            <div className="will-animate animate-fade-in-down animation-delay-100">
              <h1 className="text-5xl md:text-7xl font-extrabold text-center md:text-left" style={textPrimaryStyle}>{team.name}</h1>
              <p className="text-xl md:text-2xl text-center md:text-left mt-2 opacity-90" style={textPrimaryStyle}>{team.fullName}</p>
            </div>
          </header>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-8">
              <div className="will-animate animate-fade-in-up animation-delay-300">
                <InfoCard title="Información General" color={team.colors.accent}>
                  <ul className="space-y-3 text-lg" style={{ color: team.colors.text }}>
                    <li><strong>Fundación:</strong> {team.foundationDate}</li>
                    <li><strong>Estadio:</strong> {team.stadium}</li>
                  </ul>
                </InfoCard>
              </div>
               <div className="will-animate animate-fade-in-up animation-delay-400">
                <InfoCard title="Estadísticas del Plantel" color={team.colors.accent}>
                  <ul className="space-y-3 text-lg" style={{ color: team.colors.text }}>
                    <li><strong>Tamaño del Plantel:</strong> {team.squadSize} jugadores</li>
                    <li><strong>Extranjeros:</strong> {team.foreignPlayers} jugadores</li>
                    <li><strong>Edad Promedio:</strong> {team.averageAge} años</li>
                  </ul>
                  <div className="mt-4 pt-4 border-t" style={{ borderColor: team.colors.accent + '80' }}>
                     <h4 className="font-bold text-lg" style={{ color: team.colors.accent }}>Jugador a Seguir:</h4>
                     <p className="font-semibold text-xl mt-1">{team.playerToWatch.name} <span className="text-base opacity-80 font-normal">- {team.playerToWatch.position}</span></p>
                     <p className="mt-1 text-md opacity-90">{team.playerToWatch.description}</p>
                  </div>
                </InfoCard>
              </div>
              <div className="will-animate animate-fade-in-up animation-delay-500">
                <InfoCard title="Máximos Goleadores" color={team.colors.accent}>
                  <ul className="space-y-2 text-lg" style={{ color: team.colors.text }}>
                    {team.topScorers.map((scorer) => (
                      <li key={scorer.name} className="flex justify-between">
                        <span>{scorer.name}</span>
                        <span className="font-bold">{scorer.goals} Goles</span>
                      </li>
                    ))}
                  </ul>
                </InfoCard>
              </div>
            </div>

            <div className="space-y-8">
              <div className="will-animate animate-fade-in-up animation-delay-600">
                <InfoCard title="Rendimiento Ofensivo" color={team.colors.accent}>
                    <div className="text-center py-4">
                        <p className="text-6xl font-extrabold" style={{ color: team.colors.text }}>
                            {goalsPerGame}
                        </p>
                        <p className="text-lg opacity-90 mt-2" style={{ color: team.colors.text }}>
                            Goles por partido
                        </p>
                    </div>
                </InfoCard>
              </div>
              <div className="will-animate animate-fade-in-up animation-delay-700">
                <InfoCard title="Títulos Ganados" color={team.colors.accent}>
                  <ul className="list-disc list-inside space-y-2 text-lg" style={{ color: team.colors.text }}>
                    {team.titles.map((title) => <li key={title}>{title}</li>)}
                  </ul>
                </InfoCard>
              </div>
              <div className="will-animate animate-fade-in-up animation-delay-800">
                <InfoCard title="Evolución del Escudo" color={team.colors.accent}>
                  <p className="mb-4 text-lg" style={{ color: team.colors.text }}>
                    A lo largo de los años, el escudo ha evolucionado para representar la historia y los valores del club.
                  </p>
                  <img 
                      src={team.logoEvolutionUrl} 
                      alt="Evolución del logo" 
                      className="rounded-lg w-full object-cover shadow-md border-4"
                      style={{ borderColor: team.colors.accent }}
                  />
                </InfoCard>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeamDetail;