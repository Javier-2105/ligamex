
import React from 'react';

const FootballIcon = () => (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mr-3 text-green-400" viewBox="0 0 20 20" fill="currentColor">
        <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM5.5 8.5a.5.5 0 011 0v3a.5.5 0 01-1 0v-3zM8 6.5a.5.5 0 011 0v7a.5.5 0 01-1 0v-7zm3.5.5a.5.5 0 00-1 0v6a.5.5 0 001 0v-6z" />
        <path fillRule="evenodd" d="M3.34 7.632A8.003 8.003 0 0110 2a8.003 8.003 0 016.66 5.632l-2.428.81a5.503 5.503 0 00-8.464 0L3.34 7.632zM16.66 12.368A8.003 8.003 0 0110 18a8.003 8.003 0 01-6.66-5.632l2.428-.81a5.503 5.503 0 008.464 0l2.428.81z" clipRule="evenodd" />
    </svg>
);

export const Header: React.FC = () => {
  return (
    <header className="bg-gray-900/80 backdrop-blur-sm sticky top-0 z-50 shadow-lg shadow-black/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center h-20">
          <div className="flex items-center">
            <FootballIcon />
            <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-wider">
              Equipos de la LIGA MX
            </h1>
          </div>
        </div>
      </div>
    </header>
  );
};
