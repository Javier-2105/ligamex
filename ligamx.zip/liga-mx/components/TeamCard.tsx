
import React from 'react';
import { Team } from '../types';

interface TeamCardProps {
  team: Team;
  onSelect: (team: Team) => void;
  className?: string;
}

const TeamCard: React.FC<TeamCardProps> = ({ team, onSelect, className }) => {
  return (
    <div
      className={`bg-gray-800 rounded-xl p-4 cursor-pointer group transform hover:-translate-y-2 transition-all duration-300 ease-in-out shadow-lg hover:shadow-2xl hover:shadow-black/50 ${className || ''}`}
      onClick={() => onSelect(team)}
    >
      <div className="aspect-square flex items-center justify-center">
        <img
          src={team.logoUrl}
          alt={`${team.name} logo`}
          className="max-h-full max-w-full object-contain group-hover:scale-110 transition-transform duration-300 ease-in-out"
        />
      </div>
      <p className="text-center mt-3 font-semibold text-sm text-gray-300 group-hover:text-white transition-colors duration-300">
        {team.name}
      </p>
    </div>
  );
};

export default TeamCard;